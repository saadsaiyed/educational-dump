//
//  Drone.cpp
//

#include <cassert>

#include "Position.h"
#include "Game.h"
#include "Monster.h"
#include "Drone.h"

static const          int DAMAGE       =  5;
static const          int START_HEALTH = 50;
static const unsigned int POINTS       = 10;

static const unsigned int FACING_COUNT = 4;
static const unsigned int FACING_NORTH = 0;
static const unsigned int FACING_EAST  = 1;
static const unsigned int FACING_SOUTH = 2;
static const unsigned int FACING_WEST  = 3;
static const unsigned int FACING_START = FACING_NORTH;



Drone :: Drone ()
		: Monster (),
		  facing(FACING_START)
{
	damage = DAMAGE;
	health = START_HEALTH;
	points = POINTS;

	assert(invariant());
}

Drone :: Drone (const Position& start)
		: Monster(start),
		  facing(FACING_START)
{
	damage = DAMAGE;
	health = START_HEALTH;
	points = POINTS;

	assert(invariant());
}

Drone :: Drone (const Drone& original)
		: Monster(original),
		  facing(original.facing)
{
	assert(invariant());
	assert(original.invariant());
}

Drone :: ~Drone ()
{
	assert(invariant());
}

Drone& Drone :: operator= (const Drone& original)
{
	assert(invariant());
	assert(original.invariant());

	if(&original != this)
	{
		Monster::operator=(original);
		facing = original.facing;
	}

	assert(invariant());
	assert(original.invariant());
	return *this;
}



char Drone :: getDisplayChar () const
{
	assert(invariant());

	return 'D';
}

Monster* Drone :: getClone () const
{
	assert(invariant());

	return new Drone(*this);
}

Position Drone :: calculateMove (const Game& game,
                                 const Position& player_position)
{
	assert(invariant());

	Position ahead_position = getPosition();
	switch(facing)
	{
	case FACING_NORTH:
		ahead_position.row--;
		break;
	case FACING_EAST:
		ahead_position.column++;
		break;
	case FACING_SOUTH:
		ahead_position.row++;
		break;
	case FACING_WEST:
		ahead_position.column--;
		break;
	}

	if(!isValid(ahead_position) || game.isBlockedForMonster(ahead_position))
	{
		facing = (facing + 1) % FACING_COUNT;
		return getPosition();
	}
	else
		return ahead_position;
}



bool Drone :: invariant () const
{
	if(facing >= FACING_COUNT)
		return false;
	return true;
}
