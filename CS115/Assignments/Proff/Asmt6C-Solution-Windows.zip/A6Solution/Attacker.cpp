//
//  Attacker.cpp
//

#include "Position.h"
#include "Game.h"
#include "Monster.h"
#include "Attacker.h"

static const          int DAMAGE       =  2;
static const          int START_HEALTH = 10;
static const unsigned int POINTS       = 20;



Attacker :: Attacker ()
		: Monster ()
{
	damage = DAMAGE;
	health = START_HEALTH;
	points = POINTS;
}

Attacker :: Attacker (const Position& start)
		: Monster(start)
{
	damage = DAMAGE;
	health = START_HEALTH;
	points = POINTS;
}

Attacker :: Attacker (const Attacker& original)
		: Monster(original)
{
}

Attacker :: ~Attacker ()
{
}

Attacker& Attacker :: operator= (const Attacker& original)
{
	if(&original != this)
		Monster::operator=(original);
	return *this;
}



char Attacker :: getDisplayChar () const
{
	return 'A';
}

Monster* Attacker :: getClone () const
{
	return new Attacker(*this);
}

Position Attacker :: calculateMove (const Game& game,
                                    const Position& player_position)
{
	return calculateToPosition(game, player_position);
}
