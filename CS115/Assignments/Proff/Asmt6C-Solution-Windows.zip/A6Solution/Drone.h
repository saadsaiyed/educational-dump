//
//  Drone.h
//
//  Encapsulates a module to represent a drone monster.
//

#pragma once

#include "Position.h"
#include "Monster.h"

class Game;



//
//  Drone
//
//  A class to represent a drone monster.  A drone moves forward
//    blindly, turning right it it hits something.  It will not
//    intentionally attack the player, but may hit him or her by
//    accident.
//
//  Class Invariant:
//    <1> facing < FACING_COUNT (hidden constant)
//
class Drone : public Monster
{
public:
	Drone ();
	Drone (const Position& start);
	Drone (const Drone& original);
	virtual ~Drone ();
	Drone& operator= (const Drone& original);

	virtual char getDisplayChar () const;
	virtual Monster* getClone () const;
	virtual Position calculateMove (const Game& game,
	                                const Position& player_position);

private:
	bool invariant () const;

private:
	unsigned int facing;
};
