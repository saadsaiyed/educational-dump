//
//  Monster.h
//
//  Encapsulates a module to represent an (enemy) monster in a
//    grid-based game.
//

#pragma once

#include "Position.h"

class Game;



class Monster
{
public:
//
//  Default Constructor
//
//  Purpose: To create a dead Monster.
//  Parameter(s): N/A
//  Precondition: N/A
//  Returns: N/A
//  Side Effect: A new Monster is initialized to have 0 health
//               at position (0, 0).
//
	Monster ();

//
//  Constructor
//
//  Purpose: To create a Monster at a specific position.
//  Parameter(s):
//    <1> start: The starting position for the monster
//  Precondition:
//    <1> isValid(start)
//  Returns: N/A
//  Side Effect: A new Monster is initialized to have default
//               values and be at position start.
//
	Monster (const Position& start);

//
//  Copy Constructor
//
//  Purpose: To create a Monster as a copy of another.
//  Parameter(s):
//    <1> original: The Monster to copy
//  Precondition(s): N/A
//  Returns: N/A
//  Side Effect: The new Monster is initialized to be a copy of
//               original.
//
	Monster (const Monster& original);

//
//  Destructor
//
//  Purpose: To safely destroy a Monster.
//  Parameter(s): N/A
//  Precondition(s): N/A
//  Returns: N/A
//  Side Effect: All dynamically allocated memory for this
//               Monster is freed.
//
	virtual ~Monster ();

//
//  Assignment Operator
//
//  Purpose: To modify a Monster to be a copy of another.
//  Parameter(s):
//    <1> original: The Monster to copy
//  Precondition(s): N/A
//  Returns: A reference to this Monster
//  Side Effect: The new Monster is set to be a deep copy of
//               original.
//
	Monster& operator= (const Monster& original);

//
//  isDead
//
//  Purpose: To determine if this Monster is dead.
//  Parameter(s): N/A
//  Precondition: N/A
//  Returns: Whether this Monster is dead.
//  Side Effect: N/A
//
	bool isDead () const;

//
//  getDamage
//
//  Purpose: To determine how much damage this Monster deals
//           when attacking.
//  Parameter(s): N/A
//  Precondition: N/A
//  Returns: How much damage this Monster deals when attacking.
//  Side Effect: N/A
//
	int getDamage () const;

//
//  getPoints
//
//  Purpose: To determine how many points the player gets for
//           killing this Monster.
//  Parameter(s): N/A
//  Precondition: N/A
//  Returns: How many points are awarded for killing this
//           Monster.
//  Side Effect: N/A
//
	unsigned int getPoints () const;

//
//  getPosition
//
//  Purpose: To determine current position of this Monster.
//  Parameter(s): N/A
//  Precondition: N/A
//  Returns: This Monster's current position.
//  Side Effect: N/A
//
	const Position& getPosition () const;

//
//  getDisplayChar
//
//  Purpose: To determine that charater used to display this
//           Monster.
//  Parameter(s): N/A
//  Precondition: N/A
//  Returns: The display character.
//  Side Effect: N/A
//
	virtual char getDisplayChar () const = 0;

//
//  getClone
//
//  Purpose: To create a dynamically allocated copy of this
//           Monster.
//  Parameter(s): N/A
//  Precondition: N/A
//  Returns: A new Monster that is a deep copy of this one.
//  Side Effect: N/A
//
	virtual Monster* getClone () const = 0;

//
//  setPosition
//
//  Purpose: To change a Monster's current position.
//  Parameter(s):
//    <1> p: The new position
//  Precondition:
//    <1> isValid(p)
//  Returns: N/A
//  Side Effect: This Monster is set to be at position p.
//
	void setPosition (const Position& p);

//
//  receiveDamage
//
//  Purpose: To reduce the current health of this Monster.
//  Parameter(s):
//    <1> amount: The amount to reduce the Monster's health by
//  Precondition: N/A
//  Returns: N/A
//  Side Effect: This Monster's health is reduced by amount.
//
	void receiveDamage (int amount);

//
//  calculateMove
//
//  Purpose: To calculate this Monster's next move.
//  Parameter(s):
//    <1> Game: The Game that this Monster is moving around in
//    <2> player_position: The player's current position
//  Precondition: N/A
//  Returns: The new position for this Monster.  If this is the
//           same as player_position, this Monster is attacking
//           the player instead of moving.
//  Side Effect: The internal state of the Monster may be
//               updated.
//
	virtual Position calculateMove (
	                       const Game& game,
	                       const Position& player_position) = 0;

protected:
//
//  calculateToPosition
//
//  Purpose: To calculate the next move towards the specified
//           position.
//  Parameter(s):
//    <1> Game: The Game that this Monster is moving around in
//    <2> desired_position: The position to move towards
//  Precondition: N/A
//  Returns: The next position on the path towards
//           desired_position.
//  Side Effect: N/A
//
	Position calculateToPosition (
	                    const Game& game,
	                    const Position& desired_position) const;

protected:
	int health;
	int damage;
	unsigned int points;

private:
	Position position;
};

