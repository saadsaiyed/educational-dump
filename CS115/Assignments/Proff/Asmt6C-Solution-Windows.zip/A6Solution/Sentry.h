//
//  Sentry.h
//
//  Encapsulates a module to represent a sentry monster.
//

#pragma once

#include "Position.h"
#include "Monster.h"

class Game;



//
//  Attacker
//
//  A class to represent a sentry monster.  A sentry guards its
//    starting position.  It will attack the player if he (or
//    she) is nearby, but will not seek him out.  If the player
//    goes too far away, the sentry will return to its starting
//    position again.
//
//  Class Invariant:
//    <1> isValid(start_position)
//
class Sentry : public Monster
{
public:
	Sentry ();
	Sentry (const Position& start);
	Sentry (const Sentry& original);
	virtual ~Sentry ();
	Sentry& operator= (const Sentry& original);

	virtual char getDisplayChar () const;
	virtual Monster* getClone () const;
	virtual Position calculateMove (const Game& game,
	                                const Position& player_position);

private:
	bool invariant () const;

private:
	Position start_position;
};
