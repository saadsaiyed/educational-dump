//
//  Sentry.cpp
//

#include <cassert>

#include "Position.h"
#include "Game.h"
#include "Monster.h"
#include "Sentry.h"

static const          int DAMAGE       =  3;
static const          int START_HEALTH = 20;
static const unsigned int POINTS       = 50;



Sentry :: Sentry ()
		: Monster (),
		  start_position(getPosition())
{
	damage = DAMAGE;
	health = START_HEALTH;
	points = POINTS;

	assert(invariant());
}

Sentry :: Sentry (const Position& start)
		: Monster(start),
		  start_position(start)
{
	damage = DAMAGE;
	health = START_HEALTH;
	points = POINTS;

	assert(invariant());
}

Sentry :: Sentry (const Sentry& original)
		: Monster(original),
		  start_position(original.start_position)
{
	assert(original.invariant());
	assert(invariant());
}

Sentry :: ~Sentry ()
{
	assert(invariant());
}

Sentry& Sentry :: operator= (const Sentry& original)
{
	assert(invariant());
	assert(original.invariant());

	if(&original != this)
	{
		Monster::operator=(original);
		start_position = original.start_position;
	}

	assert(invariant());
	assert(original.invariant());
	return *this;
}



char Sentry :: getDisplayChar () const
{
	assert(invariant());

	return 'S';
}

Monster* Sentry :: getClone () const
{
	assert(invariant());

	return new Sentry(*this);
}

Position Sentry :: calculateMove (const Game& game,
                                  const Position& player_position)
{
	assert(invariant());

	double distance_to_start  = calculateDistance(getPosition(),  start_position);
	double distance_to_player = calculateDistance(getPosition(), player_position);

	if(distance_to_start + distance_to_player <= 6.0)
		return calculateToPosition(game, player_position);
	else
		return calculateToPosition(game, start_position);
}



bool Sentry :: invariant () const
{
	if(!isValid(start_position))
		return false;
	return true;
}
