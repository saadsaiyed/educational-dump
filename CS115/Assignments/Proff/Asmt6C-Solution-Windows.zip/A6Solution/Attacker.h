//
//  Attacker.h
//
//  Encapsulates a module to represent an attacker monster.
//

#pragma once

#include "Position.h"
#include "Monster.h"

class Game;



//
//  Attacker
//
//  A class to represent an attacker monster.  An attacker
//    always moves towards (or attacks) the player if possible.
//
class Attacker : public Monster
{
public:
	Attacker ();
	Attacker (const Position& start);
	Attacker (const Attacker& original);
	virtual ~Attacker ();
	Attacker& operator= (const Attacker& original);

	virtual char getDisplayChar () const;
	virtual Monster* getClone () const;
	virtual Position calculateMove (const Game& game,
	                                const Position& player_position);
};
