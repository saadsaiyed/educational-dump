//
//  Vector2.h
//
//  A class to represent a 2D position using Cartesian
//    coordinates using signed integers.
//

#pragma once



template <typename ItemType>
class Vector2
{
public:
	Vector2 ();
	Vector2 (const ItemType& x1, const ItemType& y1);
	Vector2 (const Vector2<ItemType>& original);
	~Vector2 ();
	Vector2& operator= (const Vector2<ItemType>& original);

	bool operator== (const Vector2<ItemType>& other);
	Vector2 operator+ (const Vector2<ItemType>& addend) const;
	Vector2 operator- (const Vector2<ItemType>& subtrahend) const;
	float getNorm () const;

public:
	ItemType x;
	ItemType y;
};

#include "Vector2.inl"
